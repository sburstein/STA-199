# lab01

Lab template for 8-21.
